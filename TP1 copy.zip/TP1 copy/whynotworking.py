from cmu_graphics import *
import random
import math

def onAppStart(app):
    app.url1 = '/Users/dionbaldsing/Downloads/New Piskel-1.png.png'
    app.url2 = '/Users/dionbaldsing/Downloads/New Piskel-2.png.png'
    app.url3 = '/Users/dionbaldsing/Downloads/falling-burning-pixel-meteor-flaming-asteroid-rushing-towards-planet-falling-burning-pixel-meteor-flaming-asteroid-rushing-towards-230780049-removebg-preview.png'
    app.gameStatus = 'Start'
    app.groundLevelHeight = 445
    app.groundlevelWidth = 1000
    app.asteroidCounter = 0
    app.stepsPerSecond = 4
    app.gameOver = False
    app.paused = False 
    app.steps = 0
    app.asteroidPositionX = random.randint(-40,930)
    app.asteroidPositionY = -55
    app.positionX = 0
    app.collision = False
    
    app.characterOneStartX = 200
    app.characterOneStartY = app.groundLevelHeight
    app.characterOneX = 0
    app.characterOneY = 0 
    app.characterOneHealth = 400
    
    app.characterTwoStartX = app.width - 250
    app.characterTwoStartY = app.groundLevelHeight 
    app.characterTwoX = 0
    app.characterTwoY = 0
    app.characterTwoHealth = 400
    
    app.lastUser = False
    
def drawMap(app):
    for i in range(14):  
        drawImage(app.url1, -115 + (75*i) , 400 )
        drawImage(app.url2, -115 + (75*i), 400)
    drawRect(0,app.groundLevelHeight,1000,600-app.groundLevelHeight , fill = 'red' , opacity = 0)

# def characterLists (app):
#     app.characterOneAreaList = [[],[]]
#     app.characterTwoAreaList = [[],[]]
#     for i in range(app.characterOneStartX, app.characterOneStartX + 50):
#         app.characterOneAreaList[0].append(i)
    
#     for i in range(app.characterOneStartY, app.characterOneStartY + 50):
#         app.characterOneAreaList[1].append(i)
        
#     for i in range(app.characterTwoStartX, app.characterTwoStartX + 50):
#         app.characterTwoAreaList[0].append(i)
    
#     for i in range(app.characterTwoStartY, app.characterTwoStartY + 50):
#         app.characterTwoAreaList[1].append(i)
    
#     for element in app.characterOneAreaList[0]:
#         if element in app.characterTwoAreaList[0]   :
#             app.collision = True
    
#     for element in app.characterOneAreaList[1]:
#         if element in app.characterTwoAreaList[1]   :
#             app.collision = True
             
    # print(app.characterOneAreaList, app.characterTwoAreaList)    
    

def drawCharacters (app):
    if app.collision == False:
        drawRect( app.characterOneStartX  , app.characterOneStartY - 50, 50 , 50 , fill = 'red')
        drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'blue')

        # if (app.characterOneStartX > app.characterTwoStartX or app.characterOneStartX + 50 < app.characterTwoStartX - 50) or (app.characterOneStartY > app.characterTwoStartY and app.characterOneStartY + 50 < app.characterTwoStartY -50) :
        #         drawRect( app.characterOneStartX  , app.characterOneStartY - 50, 50 , 50 , fill = 'green')
        #         drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'pink')

        characterOneArea = [(app.characterOneStartX, app.characterOneStartX + 50), (app.characterOneStartY, app.characterOneStartY + 50)]
        characterTwoArea = [(app.characterTwoStartX, app.characterTwoStartX + 50), (app.characterTwoStartY, app.characterTwoStartY + 50)]
    else:
        drawRect( app.characterOneStartX  , app.characterOneStartY - 50, 50 , 50 , fill = 'pink')
        drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'green')
  


def onStep(app):
    app.steps+=1
    if app.steps % 1 == 0:
        app.asteroidPositionY += 20
    if app.gameOver or app.paused:
        return  
        
    print(app.lastUser)
    healthChange(app)
        
    
def healthSystem (app):
    characterOneHealth = None
    characterTwoHealth = None
    
    ## CHARACTER ONE HEALTH ##
    drawRect(20,30, 20, 20, fill = 'red')
    
    if app.characterOneHealth >=300:
        characterOneHealth = 'green'
    elif app.characterOneHealth >= 200:
        characterOneHealth = 'yellow'
    elif app.characterOneHealth >= 100 :
        characterOneHealth = 'orange'
    elif app.characterOneHealth >= 100 :
        characterOneHealth = 'red'
    elif app.characterOneHealth <= 0:
        drawRect(40,35 , 400 ,10 , fill = 'red')
        
    drawRect(40,35 , app.characterOneHealth ,10 , fill = characterOneHealth)
    drawRect(40, 35 , 400 ,10 , fill = None , border = 'Black')
    
    ## CHARACTER TWO HEALTH ##
    drawRect(1000-40,30, 20, 20, fill = 'blue')
    if app.characterTwoHealth >=300:
        characterTwoHealth = 'green'
    elif app.characterTwoHealth >= 200:
        characterTwoHealth = 'yellow'
    elif app.characterTwoHealth >= 100 :
        characterTwoHealth = 'orange'
    elif app.characterTwoHealth >= 100 :
        characterTwoHealth = 'red'
        
    drawRect(1000-400-40, 35 , app.characterTwoHealth ,10 , fill = characterTwoHealth , border = 'Black')
    drawRect(1000-400-40, 35 , 400 ,10 , fill = None , border = 'Black')
    

def healthChange(app):
    right0 = app.characterOneStartX + 50
    bottom0 = app.characterOneStartY + 50
    right1 = app.characterTwoStartX + 50
    bottom1 = app.characterTwoStartY + 50
    if ((right1 >= app.characterOneStartX) and (right0 >= app.characterTwoStartX) and
        (bottom1 >= app.characterOneStartY) and (bottom0 >= app.characterTwoStartY)):
        if app.lastUser == 'One' :
            if app.characterTwoHealth < 100:
                app.gameOver = True
                app.gameStatus = 'GameOver'

            else:
                app.characterTwoHealth -= 99
                
        if app.lastUser == 'Two':
            if app.characterOneHealth < 100:
                app.gameOver = True
                app.gameStatus = 'GameOver'
            else:
                app.characterOneHealth -= 99


def drawMeteor(app):
    ## ASTROID POSITION LEFT RATIO (-40,0) , (-55,0)  , ASTROID BOX (35,35) , RIGHT RATIO (930,1000)
    # drawImage(app.url3,930, -55 )
    # drawRect(1000-35,0,35,35, opacity = 50 , fill = 'blue')
    if app.asteroidPositionY <= app.groundLevelHeight-90:
        drawImage(app.url3,app.asteroidPositionX, app.asteroidPositionY )
        drawRect(app.asteroidPositionX+35,app.asteroidPositionY + 55,35,35, opacity = 50 , fill = 'blue')
    
            


def isLegalMove (app):
    
## CHARACTER ONE CHECKS ##

    if app.characterOneStartX >= app.width:
        app.characterOneStartX = app.width - 50
        
    if  app.characterOneStartX <= 0:
        app.characterOneStartX = 0   

    if app.characterOneStartY <=  0 :
        app.characterOneStartY = 50
    
    if app.characterOneStartY >= app.groundLevelHeight:
        app.characterOneStartY = app.groundLevelHeight

    # if app.characterOneStartX >= app.characterTwoStartX :
    #     if not app.characterOneStartY  < app.characterTwoStartY:
    #         app.characterOneStartX = app.characterTwoStartX-50
    
    

## CHARACTER TWO CHECKS ##

    if app.characterTwoStartX >= app.width:
        app.characterTwoStartX = app.width - 50
        
    if  app.characterTwoStartX <= 0:
        app.characterTwoStartX = 0  
    
    if app.characterTwoStartY <=  0 :
        app.characterTwoStartY = 50
    
    if app.characterTwoStartY >= app.groundLevelHeight:
        app.characterTwoStartY = app.groundLevelHeight 
        

   
def onKeyPress(app, event):

## CHARACTER ONE MOVEMENT ##
    if event == 'left':
        if not app.gameOver:
            app.characterOneStartX -= 50
            app.lastUser = 'One'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'right':
        if not app.gameOver:
            app.characterOneStartX += 50
            app.lastUser = 'One'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'up':
        if not app.gameOver:
            app.characterOneStartY -= 50
            app.lastUser = 'One'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'down':
        if not app.gameOver:
            app.characterOneStartY += 50
            app.lastUser = 'One'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser

## CHARACTER TWO MOVEMENT ##       
    if event == 'a':
        if not app.gameOver:
            app.characterTwoStartX -= 100
            app.lastUser = 'Two'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'd':
        if not app.gameOver:
            app.characterTwoStartX += 100
            app.lastUser = 'Two'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'w':
        if not app.gameOver:
            app.characterTwoStartY -= 100
            app.lastUser = 'Two'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 's':
        if not app.gameOver:
            app.characterTwoStartY += 100
            app.lastUser = 'Two'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser


    if event == 'r':
        onAppStart(app)
        
def  characterCharacterIntersection (app):
    
    right0 = app.characterOneStartX + 50
    bottom0 = app.characterOneStartY + 50
    right1 = app.characterTwoStartX + 50
    bottom1 = app.characterTwoStartY + 50
    if ((right1 >= app.characterOneStartX) and (right0 >= app.characterTwoStartX) and
        (bottom1 >= app.characterOneStartY) and (bottom0 >= app.characterTwoStartY)):
        # they do intersect
        if app.lastUser == 'One':
            colorOne = 'red'
            colorTwo = 'yellow'
        elif app.lastUser == 'Two':
            colorOne = 'yellow'
            colorTwo = 'blue'
        
    else:
        # they do not intersect
        
        colorOne = 'red'
        colorTwo = 'blue'
    drawRect(app.characterOneStartX, app.characterOneStartY - 50 , 50, 50,
             fill=colorOne, border='black')
    drawRect(app.characterTwoStartX, app.characterTwoStartY - 50, 50, 50,
             fill=colorTwo, border='black')  

def  characterMeteorIntersection(app):
    
    right0 = app.asteroidPositionX + 70
    bottom0 = app.asteroidPositionY + 90
    right1 = app.characterTwoStartX + 50
    bottom1 = app.characterTwoStartY + 50
    if ((right1 >= app.characterOneStartX) and (right0 >= app.characterTwoStartX) and
        (bottom1 >= app.characterOneStartY) and (bottom0 >= app.characterTwoStartY)):
        # they do intersect
        if app.lastUser == 'One':
            colorOne = 'red'
            colorTwo = 'yellow'
        elif app.lastUser == 'Two':
            colorOne = 'yellow'
            colorTwo = 'blue'
        
    else:
        # they do not intersect
        
        colorOne = 'red'
        colorTwo = 'blue'
    drawRect(app.characterOneStartX, app.characterOneStartY - 50 , 50, 50,
             fill=colorOne, border='black')
    drawRect(app.characterTwoStartX, app.characterTwoStartY - 50, 50, 50,
             fill=colorTwo, border='black')  
    
    
def drawGameOverMessage(app,winner):
    if app.gameStatus == 'GameOver':
        # lastUser = app.lastUser
        drawLabel(f'Character {winner} , Won !!',500,300)
    
def redrawAll(app):        
    drawMap(app)
    drawMeteor(app)    
    drawCharacters(app)
    characterCharacterIntersection(app)
    # characterMeteorIntersection(app)
    healthSystem(app)
    
    # drawLabel(f'Character {app.lastUser} , WON !!',400,400)
    
    # if app.gameOver and app.gameStatus == 'GameOver':
    #     drawGameOverMessage(app)
    winner = None
    if app.gameStatus == 'GameOver' :
        winner = app.lastUser
        drawGameOverMessage(app,winner)
    

    
    
    

def main():
    runApp(1000,600)

main()