1) Put the TP3 folder in the desktop. And rename the folder to TP1.
2) Open the project file . Py on Visual studio code
2) From the explorer tab on the left open tab and
    make sure select 'desktop' as the folder.
3) Put all the sounds in the cmu_graphics folder where the project file 
would also be. ## For sounds to work.
4) Open the project file in visual studio and make sure step 2 is done. 
    The sounds and images should work.





