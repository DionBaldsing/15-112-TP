from cmu_graphics import *
from cmu_graphics.shape_logic import *
import random
import math
import pathlib   

cntPath = pathlib.Path(__file__).parent.resolve()  # get the current script path
hadouken = Sound(f'file://{cntPath}/Hadouken Sound effect.mp3')  # loads the mp3 (Drum1.mp3) from the local filesystem
ryuPunch = Sound(f'file://{cntPath}/punchsoundeffect.mp3') 
dhalsimYogaFire= Sound(f'file://{cntPath}/yogafire.mp3') 
dhalsimYogaFlame = Sound(f'file://{cntPath}/yogaflame.mp3') 
deathSound = Sound(f'file://{cntPath}/deathsound.mp3')
kO = Sound(f'file://{cntPath}/KO.mp3') 
background = Sound(f'file://{cntPath}/background.mp3') 
opening = Sound(f'file://{cntPath}/opening.mp3') 

# hadouken = Sound('TP1/Sounds/Hadouken Sound effect.mp3')
def onAppStart(app):
    app.url1 = 'TP1/background/New Piskel-1.png.png'
    app.url2 = 'TP1/background/New Piskel-2.png.png'
    app.ryuProfile = 'TP1/CharacterProfile/ryuprofile.png'
    app.dhalsimProfile ='TP1/CharacterProfile/dhalsimprofile.png'
    app.heart = 'TP1/CharacterProfile/heart.png'
    app.earth = ['TP1/character one/characterOne/earth000.png','TP1/character one/characterOne/earth001.png','TP1/character one/characterOne/earth002.png','TP1/character one/characterOne/earth003.png','TP1/character one/characterOne/earth004.png','TP1/character one/characterOne/earth005.png','TP1/character one/characterOne/earth006.png','TP1/character one/characterOne/earth007.png','TP1/character one/characterOne/earth008.png','TP1/character one/characterOne/earth009.png']

    app.kO = ['TP1/character one/characterOne/ko00.png','TP1/character one/characterOne/ko01.png','TP1/character one/characterOne/ko02.png','TP1/character one/characterOne/ko03.png','TP1/character one/characterOne/ko04.png','TP1/character one/characterOne/ko05.png','TP1/character one/characterOne/ko06.png','TP1/character one/characterOne/ko07.png','TP1/character one/characterOne/ko08.png','TP1/character one/characterOne/ko09.png']
    app.url3 = '/Users/dionbaldsing/Downloads/falling-burning-pixel-meteor-flaming-asteroid-rushing-towards-planet-falling-burning-pixel-meteor-flaming-asteroid-rushing-towards-230780049-removebg-preview.png'
    app.characterOneImage = [['TP1/character one/characterOne/characterone00.png','TP1/character one/characterOne/characterone01.png','TP1/character one/characterOne/characterone02.png','TP1/character one/characterOne/characterone03.png','TP1/character one/characterOne/characterone04.png','TP1/character one/characterOne/characterone05.png','TP1/character one/characterOne/characterone06.png','TP1/character one/characterOne/characterone07.png','TP1/character one/characterOne/characterone08.png','TP1/character one/characterOne/characterone09.png'],
                             ['TP1/character one/characterOne/characterOneFlip00.png','TP1/character one/characterOne/characterOneFlip01.png','TP1/character one/characterOne/characterOneFlip02.png','TP1/character one/characterOne/characterOneFlip03.png','TP1/character one/characterOne/characterOneFlip04.png','TP1/character one/characterOne/characterOneFlip05.png','TP1/character one/characterOne/characterOneFlip06.png','TP1/character one/characterOne/characterOneFlip07.png','TP1/character one/characterOne/characterOneFlip08.png','TP1/character one/characterOne/characterOneFlip09.png']]
    app.characterOneImagePunch = [['TP1/character one/characterOne/characterOnePunch00.png','TP1/character one/characterOne/characterOnePunch01.png','TP1/character one/characterOne/characterOnePunch02.png','TP1/character one/characterOne/characterOnePunch03.png','TP1/character one/characterOne/characterOnePunch04.png','TP1/character one/characterOne/characterOnePunch05.png','TP1/character one/characterOne/characterOnePunch06.png','TP1/character one/characterOne/characterOnePunch07.png','TP1/character one/characterOne/characterOnePunch08.png','TP1/character one/characterOne/characterOnePunch09.png','TP1/character one/characterOne/characterOnePunch10.png','TP1/character one/characterOne/characterOnePunch11.png','TP1/character one/characterOne/characterOnePunch12.png'],
                                  ['TP1/character one/characterOne/characterOnePunchFlip00.png','TP1/character one/characterOne/characterOnePunchFlip01.png','TP1/character one/characterOne/characterOnePunchFlip02.png','TP1/character one/characterOne/characterOnePunchFlip03.png','TP1/character one/characterOne/characterOnePunchFlip04.png','TP1/character one/characterOne/characterOnePunchFlip05.png','TP1/character one/characterOne/characterOnePunchFlip06.png','TP1/character one/characterOne/characterOnePunchFlip07.png','TP1/character one/characterOne/characterOnePunchFlip08.png','TP1/character one/characterOne/characterOnePunchFlip09.png','TP1/character one/characterOne/characterOnePunchFlip10.png','TP1/character one/characterOne/characterOnePunchFlip11.png','TP1/character one/characterOne/characterOnePunchFlip12.png']]
    app.characterOneImageLongPunch = [['TP1/character one/characterOne/characterOneLongPunch0.png','TP1/character one/characterOne/characterOneLongPunch1.png','TP1/character one/characterOne/characterOneLongPunch2.png','TP1/character one/characterOne/characterOneLongPunch3.png'],
                                      ['TP1/character one/characterOne/characterOneLongPunchFlip0.png','TP1/character one/characterOne/characterOneLongPunchFlip1.png','TP1/character one/characterOne/characterOneLongPunchFlip2.png','TP1/character one/characterOne/characterOneLongPunchFlip3.png']]
    app.characterTwoImage = [['TP1/character one/characterOne/charactertwo0.png','TP1/character one/characterOne/charactertwo1.png','TP1/character one/characterOne/charactertwo2.png','TP1/character one/characterOne/charactertwo3.png','TP1/character one/characterOne/charactertwo4.png','TP1/character one/characterOne/charactertwo5.png'],
                             ['TP1/character one/characterOne/charactertwoFlip0.png','TP1/character one/characterOne/charactertwoFlip1.png','TP1/character one/characterOne/charactertwoFlip2.png','TP1/character one/characterOne/charactertwoFlip3.png','TP1/character one/characterOne/charactertwoFlip4.png','TP1/character one/characterOne/charactertwoFlip5.png']]
    app.characterTwoImagePunch = [['TP1/character one/characterOne/characterTwoPunchFlip00.png','TP1/character one/characterOne/characterTwoPunchFlip01.png','TP1/character one/characterOne/characterTwoPunchFlip02.png','TP1/character one/characterOne/characterTwoPunchFlip03.png','TP1/character one/characterOne/characterTwoPunchFlip04.png','TP1/character one/characterOne/characterTwoPunchFlip05.png','TP1/character one/characterOne/characterTwoPunchFlip06.png','TP1/character one/characterOne/characterTwoPunchFlip07.png','TP1/character one/characterOne/characterTwoPunchFlip08.png','TP1/character one/characterOne/characterTwoPunchFlip09.png','TP1/character one/characterOne/characterTwoPunch10Flip.png','TP1/character one/characterOne/characterTwoPunchFlip24.png','TP1/character one/characterOne/characterTwoPunchFlip25.png','TP1/character one/characterOne/characterTwoPunchFlip26.png','TP1/character one/characterOne/characterTwoPunchFlip27.png','TP1/character one/characterOne/characterTwoPunchFlip28.png','TP1/character one/characterOne/characterTwoPunchFlip29.png','TP1/character one/characterOne/characterTwoPunchFlip30.png','TP1/character one/characterOne/characterTwoPunchFlip31.png'],
                                  ['TP1/character one/characterOne/characterTwoPunch00.png','TP1/character one/characterOne/characterTwoPunch01.png','TP1/character one/characterOne/characterTwoPunch02.png','TP1/character one/characterOne/characterTwoPunch03.png','TP1/character one/characterOne/characterTwoPunch04.png','TP1/character one/characterOne/characterTwoPunch05.png','TP1/character one/characterOne/characterTwoPunch06.png','TP1/character one/characterOne/characterTwoPunch07.png','TP1/character one/characterOne/characterTwoPunch08.png','TP1/character one/characterOne/characterTwoPunch09.png','TP1/character one/characterOne/characterTwoPunch10.png','TP1/character one/characterOne/characterTwoPunch24.png','TP1/character one/characterOne/characterTwoPunch25.png','TP1/character one/characterOne/characterTwoPunch26.png','TP1/character one/characterOne/characterTwoPunch27.png','TP1/character one/characterOne/characterTwoPunch28.png','TP1/character one/characterOne/characterTwoPunch29.png','TP1/character one/characterOne/characterTwoPunch30.png','TP1/character one/characterOne/characterTwoPunch31.png']]
    app.characterTwoImageLongPunch = [[
    
    'TP1/character one/characterOne/characterTwoLongPunchFlip00.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip01.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip02.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip03.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip04.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip05.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip06.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip07.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip08.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip09.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip10.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip11.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip12.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip13.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip14.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip15.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip16.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip17.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip18.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip19.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip20.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip21.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip22.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip23.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip24.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip25.png',
    'TP1/character one/characterOne/characterTwoLongPunchFlip26.png',
    
],[
    'TP1/character one/characterOne/characterTwoLongPunch00.png',
    'TP1/character one/characterOne/characterTwoLongPunch01.png',
    'TP1/character one/characterOne/characterTwoLongPunch02.png',
    'TP1/character one/characterOne/characterTwoLongPunch03.png',
    'TP1/character one/characterOne/characterTwoLongPunch04.png',
    'TP1/character one/characterOne/characterTwoLongPunch05.png',
    'TP1/character one/characterOne/characterTwoLongPunch06.png',
    'TP1/character one/characterOne/characterTwoLongPunch07.png',
    'TP1/character one/characterOne/characterTwoLongPunch08.png',
    'TP1/character one/characterOne/characterTwoLongPunch09.png',
    'TP1/character one/characterOne/characterTwoLongPunch10.png',
    'TP1/character one/characterOne/characterTwoLongPunch11.png',
    'TP1/character one/characterOne/characterTwoLongPunch12.png',
    'TP1/character one/characterOne/characterTwoLongPunch13.png',
    'TP1/character one/characterOne/characterTwoLongPunch14.png',
    'TP1/character one/characterOne/characterTwoLongPunch15.png',
    'TP1/character one/characterOne/characterTwoLongPunch16.png',
    'TP1/character one/characterOne/characterTwoLongPunch17.png',
    'TP1/character one/characterOne/characterTwoLongPunch18.png',
    'TP1/character one/characterOne/characterTwoLongPunch19.png',
    'TP1/character one/characterOne/characterTwoLongPunch20.png',
    'TP1/character one/characterOne/characterTwoLongPunch21.png',
    'TP1/character one/characterOne/characterTwoLongPunch22.png',
    'TP1/character one/characterOne/characterTwoLongPunch23.png',
    'TP1/character one/characterOne/characterTwoLongPunch24.png',
    'TP1/character one/characterOne/characterTwoLongPunch25.png',
    'TP1/character one/characterOne/characterTwoLongPunch26.png',
    'TP1/character one/characterOne/characterTwoLongPunch27.png',
    'TP1/character one/characterOne/characterTwoLongPunch28.png',
    'TP1/character one/characterOne/characterTwoLongPunch29.png',
    'TP1/character one/characterOne/characterTwoLongPunch30.png',
    'TP1/character one/characterOne/characterTwoLongPunch31.png'
]]
    app.backgroundImage = [
    'TP1/background/background00.png',
    'TP1/background/background01.png',
    'TP1/background/background02.png',
    'TP1/background/background03.png',
    'TP1/background/background04.png',
    'TP1/background/background05.png',
    'TP1/background/background06.png',
    'TP1/background/background07.png',
    'TP1/background/background08.png',
    'TP1/background/background09.png',
    'TP1/background/background10.png',
    'TP1/background/background11.png',
    'TP1/background/background12.png',
    'TP1/background/background13.png',
    'TP1/background/background14.png',
    'TP1/background/background15.png',
    'TP1/background/background16.png',
    'TP1/background/background17.png',
    'TP1/background/background18.png',
    'TP1/background/background19.png',
    'TP1/background/background20.png',
    'TP1/background/background21.png',
    'TP1/background/background22.png',
    'TP1/background/background23.png',
    'TP1/background/background24.png',
    'TP1/background/background25.png',
    'TP1/background/background26.png',
    'TP1/background/background27.png',
    'TP1/background/background28.png',
    'TP1/background/background29.png',
    'TP1/background/background30.png',
    'TP1/background/background31.png',
    'TP1/background/background32.png',
    'TP1/background/background33.png',
    'TP1/background/background34.png',
    'TP1/background/background35.png',
    'TP1/background/background36.png',
    'TP1/background/background37.png',
    'TP1/background/background38.png',
    'TP1/background/background39.png',
    'TP1/background/background40.png',
    'TP1/background/background41.png',
    'TP1/background/background42.png',
    'TP1/background/background43.png',
    'TP1/background/background44.png',
    'TP1/background/background45.png',
    'TP1/background/background46.png',
    'TP1/background/background47.png',
    'TP1/background/background48.png',
    'TP1/background/background49.png',
    'TP1/background/background50.png',
    'TP1/background/background51.png',
    'TP1/background/background52.png',
    'TP1/background/background53.png',
    'TP1/background/background54.png',
    'TP1/background/background55.png',
    'TP1/background/background56.png',
    'TP1/background/background57.png',
    'TP1/background/background58.png',
    'TP1/background/background59.png',
    'TP1/background/background60.png',
    'TP1/background/background61.png',
    'TP1/background/background62.png',
    'TP1/background/background63.png',
    'TP1/background/background64.png',
    'TP1/background/background65.png'
]
    
    
    app.gameStatus = 'Menu'
    app.groundLevelHeight = 445
    app.groundlevelWidth = 1000
    app.asteroidCounter = 0
    app.stepsPerSecond = 10
    app.gameOver = False
    app.paused = False 
    app.steps = 0
    app.asteroidPositionX = random.randint(-40,930)
    app.asteroidPositionY = -55
    app.asteroidCount = 0
    app.positionX = 0
    app.collision = None
    app.asteroidCollision = False
    app.drawImage = True
    app.backgroundCounter = 0
    app.winner = False
    app.lastlifeCounter = 0
    app.koImageCounter = 0
    
    app.characterOneStartX = 200
    app.characterOneStartY = app.groundLevelHeight
    app.characterOneX = 0
    app.characterOneY = 0 
    app.characterOneHealth = 400
    app.characterOneFlip = 0
    app.imageCounter1 = 0
    app.imageCounter1Long = 0
    app.characterOneHitAvail = False
    app.characterOneHit = False
    app.characterOneHitLong = False
    app.characterOneLife = ['one','two','three']
    app.characterOneLastLife = False
    app.characterOneDy = 0
    app.characterOneIsJumping = False
    app.characterOneMaxHeight = False

    
    app.characterTwoStartX = app.width - 250
    app.characterTwoStartY = app.groundLevelHeight 
    app.characterTwoX = 0
    app.characterTwoY = 0
    app.characterTwoHealth = 400
    app.characterTwoFlip = 1
    app.imageCounter2 = 0
    app.imageCounter2Long = 0
    app.characterTwoHitAvail = False
    app.characterTwoHit = False
    app.characterTwoHitLong = False
    app.characterTwoLife = ['one','two','three']
    app.characterTwoLastLife = False
    app.characterTwoIsJumping = False
    app.characterTwoMaxHeight = False

    app.lastUser = False
    
def drawMap(app):
    for i in range(14):  
        drawImage(app.url1, -115 + (75*i) , 400 )
        drawImage(app.url2, -115 + (75*i), 400)
    drawRect(0,app.groundLevelHeight,1000,600-app.groundLevelHeight , fill = 'red' , opacity = 0)

# def characterLists (app):
#     app.characterOneAreaList = [[],[]]
#     app.characterTwoAreaList = [[],[]]
#     for i in range(app.characterOneStartX, app.characterOneStartX + 50):
#         app.characterOneAreaList[0].append(i)
    
#     for i in range(app.characterOneStartY, app.characterOneStartY + 50):
#         app.characterOneAreaList[1].append(i)
        
#     for i in range(app.characterTwoStartX, app.characterTwoStartX + 50):
#         app.characterTwoAreaList[0].append(i)
    
#     for i in range(app.characterTwoStartY, app.characterTwoStartY + 50):
#         app.characterTwoAreaList[1].append(i)
    
#     for element in app.characterOneAreaList[0]:
#         if element in app.characterTwoAreaList[0]   :
#             app.collision = True
    
#     for element in app.characterOneAreaList[1]:
#         if element in app.characterTwoAreaList[1]   :
#             app.collision = True
             
    # print(app.characterOneAreaList, app.characterTwoAreaList)    
    

def drawCharacters (app):
    if app.collision == False:
        drawRect( app.characterOneStartX  , app.characterOneStartY - 50, 50 , 50 , fill = 'red')
        drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'blue')


        # if (app.characterOneStartX > app.characterTwoStartX or app.characterOneStartX + 50 < app.characterTwoStartX - 50) or (app.characterOneStartY > app.characterTwoStartY and app.characterOneStartY + 50 < app.characterTwoStartY -50) :
        #         drawRect( app.characterOneStartX  , app.characterOneStartY - 50, 50 , 50 , fill = 'green')
        #         drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'pink')

        characterOneArea = [(app.characterOneStartX, app.characterOneStartX + 50), (app.characterOneStartY, app.characterOneStartY + 50)]
        characterTwoArea = [(app.characterTwoStartX, app.characterTwoStartX + 50), (app.characterTwoStartY, app.characterTwoStartY + 50)]
    else:
        drawRect( app.characterOneStartX  , app.characterOneStartY - 200, 50 , 50 , fill = 'pink')
        drawRect( app.characterTwoStartX , app.characterTwoStartY - 50 , 50 , 50, fill = 'green')
    


def onStep(app):
    app.steps+=1

    if app.gameStatus == 'Pause' :
        if app.koImageCounter <= 8:
            app.koImageCounter +=1
        else:
            app.koImageCounter = 0
            
    if app.gameStatus == 'GameOver' :
        deathSound.play(loop = False , restart= False)
        if app.koImageCounter <= 8:
            app.koImageCounter +=1
        else:
            app.koImageCounter = 0
        
        # deathSound.pause()
        kO.play(loop = False, restart = False)
    if app.gameStatus == 'Menu':
        if app.backgroundCounter <= 63:
            app.backgroundCounter +=1
        else:
            app.backgroundCounter = 0
            
    if app.gameStatus == 'Start':
        
        if app.characterOneIsJumping and app.characterOneStartY <= app.groundLevelHeight:
            if app.characterOneStartY <= 350:
                app.characterOneIsJumping = False
                app.characterOneMaxHeight = True
            else:
                app.characterOneStartY  -= 45 
                
        if app.characterOneMaxHeight == True:
            if app.characterOneStartY >= app.groundLevelHeight:
                app.characterOneStartY = app.groundLevelHeight
                app.characterOneMaxHeight = False
            else:  
                app.characterOneStartY += 45
        
        if app.characterTwoIsJumping and app.characterTwoStartY <= app.groundLevelHeight:
            if app.characterTwoStartY <= 350:
                app.characterTwoIsJumping = False
                app.characterTwoMaxHeight = True
            else:
                app.characterTwoStartY  -= 45
        
        if app.characterTwoMaxHeight == True:
            if app.characterTwoStartY >= app.groundLevelHeight:
                app.characterTwoStartY = app.groundLevelHeight
                app.characterTwoMaxHeight = False
            else:  
                app.characterTwoStartY += 45
        
        if app.characterOneHealth > app.characterTwoHealth:
            app.winner = 'One'
        else:
            app.winner = 'Two'
            
        if app.characterOneHealth <= 1 or app.characterTwoHealth <=1:
            app.gameOver = True
            app.gameStatus = 'GameOver'
        
        
        if app.steps %2 == 0:
            app.asteroidPositionY += 20
        if app.steps % 1 == 0:
            if app.imageCounter1 < 11:
                app.imageCounter1+=1
            else:
                app.imageCounter1 = 0
            
            if app.imageCounter1Long <= 2:
                app.imageCounter1Long +=1
            else:
                app.imageCounter1Long = 0
                
                  
            if app.imageCounter2 <= 4:
                app.imageCounter2+=1
            else:
                app.imageCounter2 = 0
            
               
            if app.imageCounter2Long <= 23:
                app.imageCounter2Long+=1
            else:
                app.imageCounter2Long = 0
            
            
                
                
        # if app.gameOver or app.paused:
        #     return  
        
        # if app.asteroidCollision == True:
        #     if app.collision == True:
        #         app.characterOneHealth -= 20
        #         app.asteroidCollision = False
        #     else:
        #         app.characterTwoHealth -= 20
        #         app.asteroidCollision = False

                
        # print(app.lastUser)
        # print(f'THE LIFE COUNT OF TWO: {app.characterTwoLife}')
        # print(app.asteroidCollision)
        # print(app.characterOneHit , app.characterTwoHit)
        if healthChange(app) or (app.asteroidPositionY >= app.groundLevelHeight-90):
            app.asteroidPositionY = -55
            app.asteroidPositionX = random.randint(-40,930) 
            app.asteroidCount += 1
            
    
    
    
        
        
def drawLifeBars (app):
    for i in range(len(app.characterOneLife)-1):
        drawRect(40 + (50*i),60, 25, 25, fill = 'gold' , border = 'black')
        # drawImage(app.heart,40 + (50*i), 60 , width = 40, height = 40)
    
    for i in range(len(app.characterTwoLife)-1):
        drawRect(1000-60 - (50*i),60, 25, 25, fill = 'gold' , border = 'black')
        # drawImage(app.heart,1000-60 - (50*i), 60, width = 40, height = 40)


        
    
def healthSystem (app):
    characterOneHealth = None
    characterTwoHealth = None
    
    ## CHARACTER ONE HEALTH ##
    drawRect(20,30, 20, 20, fill = 'red')
    
    if app.characterOneHealth >=300:
        characterOneHealth = 'green'
    elif app.characterOneHealth >= 200:
        characterOneHealth = 'yellow'
    elif app.characterOneHealth >= 100 :
        characterOneHealth = 'orange'
    elif app.characterOneHealth >= 100 :
        characterOneHealth = 'red'
    elif app.characterOneHealth <= 100:
        characterOneHealth = 'red'
    
    if app.characterOneHealth >= 20:
        drawRect(40,35 , abs(app.characterOneHealth) ,10 , fill = characterOneHealth)
        drawRect(40, 35 , 400 ,10 , fill = None , border = 'Black')
    
    ## CHARACTER TWO HEALTH ##
    drawRect(1000-40,30, 20, 20, fill = 'blue')
    if app.characterTwoHealth >=300:
        characterTwoHealth = 'green'
    elif app.characterTwoHealth >= 200:
        characterTwoHealth = 'yellow'
    elif app.characterTwoHealth >= 100 :
        characterTwoHealth = 'orange'
    elif app.characterTwoHealth >= 100 :
        characterTwoHealth = 'red'
    elif app.characterTwoHealth <= 100:
        characterTwoHealth = 'red'
        
    drawRect(1000-400-40, 35 , abs(app.characterTwoHealth) ,10 , fill = characterTwoHealth , border = 'Black')
    drawRect(1000-400-40, 35 , 400 ,10 , fill = None , border = 'Black')
    

def healthChange(app):
    right0 = app.characterOneStartX + 125
    bottom0 = app.characterOneStartY + 20
    right1 = app.characterTwoStartX + 125
    bottom1 = app.characterTwoStartY + 20
    right2 = app.asteroidPositionX + 70
    bottom2 = app.asteroidPositionY + 90
    
    if ((right2 >= app.characterOneStartX) and (right0 >= app.asteroidPositionX) and 
        (bottom2 >= app.characterOneStartY - 225) and (bottom0 >= app.asteroidPositionY)):
        
        app.characterOneHealth -= 29
        return True

    if ((right2 >= app.characterTwoStartX) and (right1 >= app.asteroidPositionX) and 
        (bottom2 >= app.characterTwoStartY - 225) and (bottom1 >= app.asteroidPositionY )):
        
        app.characterTwoHealth -= 29
        return True
        
    if ((right1 >= app.characterOneStartX) and (right0 >= app.characterTwoStartX) and
        (bottom1 >= app.characterOneStartY - 225 ) and (bottom0 >= app.characterTwoStartY - 225)):
        if app.lastUser == 'One' :
            if app.characterTwoHealth < 30:
                if len(app.characterTwoLife) > 2:
                    onAppStart(app)
                    app.characterTwoLife.pop()
                    app.gameStatus = 'Start'
                    
                # else:
                #     app.gameOver = True
                #     app.gameStatus = 'GameOver'

            else:
                # app.characterTwoHealth -= 29
                app.characterOneHitAvail = True
                app.characterTwoHitAvail = False
                
        if app.lastUser == 'Two':
            if app.characterOneHealth < 30:
                if len(app.characterOneLife) > 2:
                    onAppStart(app)
                    app.characterOneLife.pop()
                    app.gameStatus = 'Start'
                    
                # else:
                #     app.gameOver = True
                #     app.gameStatus = 'GameOver'
            else:
                # app.characterOneHealth -= 29
                app.characterTwoHitAvail = True
                app.characterOneHitAvail = False
    else:
        app.characterOneHitAvail = False
        app.characterTwoHitAvail = False
    
    


def drawMeteor(app):
    ## ASTROID POSITION LEFT RATIO (-40,0) , (-55,0)  , ASTROID BOX (35,35) , RIGHT RATIO (930,1000)
    # drawImage(app.url3,930, -55 )
    # drawRect(1000-35,0,35,35, opacity = 50 , fill = 'blue')
    
    
    if app.asteroidPositionY <= app.groundLevelHeight-90:
        
        drawImage(app.url3,app.asteroidPositionX, app.asteroidPositionY )
        drawRect(app.asteroidPositionX+35,app.asteroidPositionY + 55,35,35, opacity = 0 , fill = 'blue')

    else:
        return True
    
   
            


def isLegalMove (app):
    
## CHARACTER ONE CHECKS ##

    if app.characterOneStartX >= app.width:
        app.characterOneStartX = app.width - 50
        
    if  app.characterOneStartX <= 0:
        app.characterOneStartX = 0   

    if app.characterOneStartY <=  0 :
        app.characterOneStartY = 50
    
    if app.characterOneStartY >= app.groundLevelHeight:
        app.characterOneStartY = app.groundLevelHeight

    # if app.characterOneStartX >= app.characterTwoStartX :
    #     if not app.characterOneStartY  < app.characterTwoStartY:
    #         app.characterOneStartX = app.characterTwoStartX-50
    
    

## CHARACTER TWO CHECKS ##

    if app.characterTwoStartX >= app.width:
        app.characterTwoStartX = app.width - 50
        
    if  app.characterTwoStartX <= 0:
        app.characterTwoStartX = 0  
    
    if app.characterTwoStartY <=  0 :
        app.characterTwoStartY = 50
    
    if app.characterTwoStartY >= app.groundLevelHeight:
        app.characterTwoStartY = app.groundLevelHeight 
        

def onMousePress (app,mouseX,mouseY):
    if app.gameStatus == 'Menu':
        if mouseX >= (app.width/2 - 50)  and mouseX <= (app.width/2 + 50) and mouseY >= (app.height/3 - 50)  and mouseY <= (app.height/3 + 50):
            app.gameStatus = 'Start'
        if mouseX >= (app.width/2 - 50)  and mouseX <= (app.width/2 + 50) and mouseY >= (app.height/1.6 - 50)  and mouseY <= (app.height/1.6 + 50):
            app.gameStatus = 'Controls'


###drawRect(100,50,200,200, fill = 'darkblue' ) 
    #drawRect(100,350,200,200 , fill = 'darkred' )
    if app.gameStatus == 'Controls' or app.gameStatus == 'RyuControls' or app.gameStatus == 'DhalsimControls' :
        if mouseX >= 100 and mouseX <= 300 and mouseY >=50 and mouseY <= 250:
            app.gameStatus = 'RyuControls'
        if mouseX >= 100 and mouseX <= 300 and mouseY >=350 and mouseY <= 550:
            app.gameStatus = 'DhalsimControls'

        
def onKeyPress(app, event):

## CHARACTER ONE MOVEMENT ##
    if event == 'left':
        if not app.gameOver:
            app.characterOneStartX -= 50
            app.lastUser = 'One'
            app.characterOneFlip = 1
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'right':
        if not app.gameOver:
            app.characterOneStartX += 50
            app.lastUser = 'One'
            app.characterOneFlip = 0
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'up':
        if not app.gameOver:
            app.characterOneIsJumping = True
            # app.characterOneStartY -= 50
            # app.lastUser = 'One'
            # isLegalMove(app)
        else:
            app.lastUser = app.lastUser
        
    if event == 'down':
        if not app.gameOver:
            app.characterOneStartY += 50
            app.lastUser = 'One'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if app.characterOneHitAvail == True:
        if event == 'm':
            app.characterOneHit = True
            app.characterTwoHealth -= 9
            
        else:
            app.characterOneHit = False
    else:
        if event == 'm':
            app.characterOneHit = True
        else:
            app.characterOneHit = False
            
            
    if app.characterOneHitAvail == True:  
        if event == 'l':
            app.characterOneHitLong = True
            app.characterTwoHealth -= 14
        else:
            app.characterOneHitLong = False
    else:
        if event == 'l':
            app.characterOneHitLong = True
        else:
            app.characterOneHitLong = False
        
    
    

## CHARACTER TWO MOVEMENT ##       
    if event == 'a':
        if not app.gameOver:
            app.characterTwoStartX -= 50
            app.lastUser = 'Two'
            app.characterTwoFlip = 1
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'd':
        if not app.gameOver:
            app.characterTwoStartX += 50
            app.lastUser = 'Two'
            app.characterTwoFlip = 0

            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 'w':
        if not app.gameOver:
            app.characterTwoIsJumping = True
            # app.characterTwoStartY -= 50
            # app.lastUser = 'Two'
            # isLegalMove(app)
        else:
            app.lastUser = app.lastUser
    if event == 's':
        if not app.gameOver:
            app.characterTwoStartY += 50
            app.lastUser = 'Two'
            isLegalMove(app)
        else:
            app.lastUser = app.lastUser
            
    if app.characterTwoHitAvail == True:
        if event == 'y':
            app.characterTwoHit = True
            app.characterOneHealth -= 9 #29
        else:
            app.characterTwoHit = False
    else:
        if event == 'y':
            app.characterTwoHit = True
        else:
            app.characterTwoHit = False

    if app.characterTwoHitAvail == True:
        if event == 'v':
            app.characterTwoHitLong = True
            app.characterOneHealth -= 14
        else:
            app.characterTwoHitLong = False
        
    else:
        if event == 'v':
            app.characterTwoHitLong = True
        else:
            app.characterTwoHitLong = False   
            
            
    if event == 'r':
        onAppStart(app)
    if event == 'p':
        if app.gameStatus != 'Pause':
            app.gameStatus = 'Pause'
        else:
            app.gameStatus = 'Start'


# def onKeyHold(app,keys):
#     if 'v' in keys and 'y' in keys:
#         app.characterOneHealth -=100
#         app.characterOneHealth = 200
        
def onKeyRelease (app, key):
    if key is ' m ':
        app.characterOneHit = False
        app.characterOneHitLong = False
    
    if key is 'l':
        app.characterOneHit = False
    
    

# def onKeyHold(app, keys):
    # if app.characterTwoHitAvail == True:
    #     if 'v'  in keys:
    #         app.characterTwoHitLong = True
    #         app.characterOneHealth -= 30
    #     else:
    #         app.characterTwoHitLong = False
                       
def  characterCharacterIntersection (app):
    
    right0 = app.characterOneStartX + 125
    bottom0 = app.characterOneStartY + 20
    right1 = app.characterTwoStartX + 125
    bottom1 = app.characterTwoStartY + 20
    
    if ((right1 >= app.characterOneStartX) and (right0 >= app.characterTwoStartX) and
        (bottom1 >= app.characterOneStartY - 225 ) and (bottom0 >= app.characterTwoStartY - 225)):
        # they do intersect
        if app.lastUser == 'One':
            colorOne = 'red'
            colorTwo = 'yellow'
        elif app.lastUser == 'Two':
            colorOne = 'yellow'
            colorTwo = 'blue'
        
    else:
        # they do not intersect
        
        colorOne = 'red'
        colorTwo = 'blue'
    drawRect(app.characterOneStartX, app.characterOneStartY - 225 , 125, 245,
             fill=colorOne, border='black', opacity = 0)
    drawRect(app.characterTwoStartX, app.characterTwoStartY - 225, 125, 245,
             fill=colorTwo, border='black', opacity = 0 )  

def  characterMeteorIntersection(app):
    
    right1 = app.asteroidPositionX + 70
    bottom1 = app.asteroidPositionY + 90
    right0 = app.characterTwoStartX + 50
    bottom0 = app.characterTwoStartY + 50
    if ((right1 >= app.characterTwoStartX) and (right0 >= app.asteroidPositionX) and 
        (bottom1 >= app.characterTwoStartY) and (bottom0 >= app.asteroidPositionY )):
        # they do intersect
        
        colorOne = 'yellow'
        colorTwo = 'pink'
        drawRect(app.asteroidPositionX+35, app.asteroidPositionY+55 , 35, 35,
             fill=colorOne, border='black')
    else:
        # they do not intersect
        
        colorOne = 'red'
        colorTwo = 'blue'
        drawRect(app.asteroidPositionX+35, app.asteroidPositionY+55 , 35, 35,
             fill=colorOne, border='black')
        

def drawMenu(app):
    
    drawImage(app.backgroundImage[app.backgroundCounter],0,0)    
    drawRect(app.width/2 - 100,app.height/3 - 50, 200,100, fill = 'red', border = 'black' )  
    drawLabel('PLAY GAME', app.width/2, app.height/3, size = 30 , font = ' monospace' , bold = True)
    drawRect(app.width/2 - 100,app.height/1.6 - 50, 200,100, fill = 'red', border = 'black' )  
    drawLabel('CONTROLS', app.width/2, app.height/1.6, size = 30 , font = ' monospace', bold = True)
    for i in range(14):  
        drawImage(app.url1, -115 + (75*i) , 400 )
        drawImage(app.url2, -115 + (75*i), 400)
    drawRect(0,app.groundLevelHeight,1000,600-app.groundLevelHeight , fill = 'red' , opacity = 0)

def drawControls(app):
    drawRect(0,0,app.width,app.height,fill='darkSeaGreen')
    drawRect(100,50,200,200, fill = 'darkblue' ) 
    drawRect(100,350,200,200 , fill = 'darkred' )
    drawImage(app.dhalsimProfile ,100  ,350 , width = 200 , height = 200, border = 'black' , borderWidth = 6)
    drawImage(app.ryuProfile ,100  ,50 , width = 200 , height = 200, border = 'black' , borderWidth = 6)
    if app.gameStatus == 'Controls':
        drawLabel ('Click on Character' , app.width/1.5 , app.height/2, size = 30 , font = 'monospace', bold = True)
    

def drawRyuControls(app):
    drawLabel('RYU (CHARACTER ONE)',app.width/1.5, 75 , size = 45, font = 'monospace' , bold = True)

    drawLabel('MOVEMENT',app.width/1.5, 150 , size = 30, font = 'monospace' , bold = True)

    drawLabel('LEFT: Left Arrow Button ',app.width/1.5, 200 , size = 20, font = 'monospace' , bold = True)
    drawLabel('RIGHT: Right Arrow Button',app.width/1.5, 250 , size = 20, font = 'monospace' , bold = True)
    drawLabel('JUMP: Top Arrow Button',app.width/1.5, 300 , size = 20, font = 'monospace' , bold = True)
    # drawLabel('PUNCH: Deals 10 DAMAGE ',app.width/1.5, 200 , size = 20, font = 'monospace' , bold = True)

    drawLabel('ATTACK MOVES ',app.width/1.5, 400 , size = 30, font = 'monospace' , bold = True)
    drawLabel('PUNCH: Deals 10 DAMAGE : M Button  ',app.width/1.5, 450 , size = 20, font = 'monospace' , bold = True)
    drawLabel('HADOUKEN: Deals 15 DAMAGE : L Button', app.width/1.5, 500, size = 20 , font = 'monospace' ,  bold = True)


def drawDhalsimControls(app):
    drawLabel('Dhalsim (CHARACTER TWO)',app.width/1.5, 75 , size = 45, font = 'monospace' , bold = True)

    drawLabel('MOVEMENT',app.width/1.5, 150 , size = 30, font = 'monospace' , bold = True)
    drawLabel('LEFT: A Button',app.width/1.5, 200 , size = 20, font = 'monospace' , bold = True)
    drawLabel('RIGHT: D Button',app.width/1.5, 250 , size = 20, font = 'monospace' , bold = True)
    drawLabel('JUMP: W Button',app.width/1.5, 300 , size = 20, font = 'monospace' , bold = True)
    # drawLabel('PUNCH: Deals 10 DAMAGE ',app.width/1.5, 200 , size = 20, font = 'monospace' , bold = True)

    drawLabel('ATTACK MOVES ',app.width/1.5, 400 , size = 30, font = 'monospace' , bold = True)
    drawLabel('YOGA FIRE: Deals 10 DAMAGE : Y Button', app.width/1.5, 450 ,size = 20, font = 'monospace', bold = True)
    drawLabel('YOGA FLAME: Deals 15 DAMAGE : V Button',app.width/1.5, 500, size = 20, font = 'monospace', bold = True)

    
def drawPause(app):
    drawImage(app.earth[app.koImageCounter],0,0, width = 1000, height = 600)
    drawLabel ('GAME PAUSED', 225 , 550 , size = 60 , font = 'monospace' , fill = 'white', bold = True)
    

def characterLife(app):
    if len(app.characterOneLife) == 2:
        drawLabel('Player One Lives Left: 1', app.width/2, app.height/6, size = 25 , font='monospace',border = 'black' , borderWidth = 1, fill = 'red')        
    if len(app.characterTwoLife) == 2:
        drawLabel('Player Two Lives Left: 1', app.width/2, app.height/6, size = 25, font = 'monospace',border = 'black' , borderWidth = 1, fill= 'red')        
                    
def drawGameOverMessage(app,winner):
    if app.gameStatus == 'GameOver':
        drawRect(0,0,app.width,app.height, fill ='antiqueWhite')
        # lastUser = app.lastUser
        drawImage(app.kO[app.koImageCounter],app.width/2 - 100  ,150 , width= 200, height = 200)
        drawLabel(f'Character {winner} , Won !!',app.width/2,400 , size = 50 , font = 'monospace' , bold = True)
        if app.steps%2 == 0:
            drawLabel(f'Press R to restart',app.width/2,500 , size = 30 , font = 'monospace' , bold = True , fill = 'red')



    
def redrawAll(app): 
    if app.gameStatus == 'Menu':
        drawMenu(app)
        opening.play(loop=False, restart= False)
        

    if app.gameStatus == 'Controls' or app.gameStatus == 'RyuControls' or app.gameStatus == 'DhalsimControls':
        drawControls(app)
        opening.play(loop = False, restart = False)
        if app.gameStatus == 'RyuControls':
            drawRyuControls(app)
        if app.gameStatus == 'DhalsimControls':
            drawDhalsimControls(app)
        
        
    if app.gameStatus == 'Pause':
        drawPause(app)
    if app.gameStatus == 'Start' : 
        opening.pause()
        background.play(loop=False)
        drawImage(app.backgroundImage[0],0,0)     
        drawMap(app)
        drawMeteor(app)
        
        # drawCharacters(app)
        characterCharacterIntersection(app)
        # characterMeteorIntersection(app)
        healthSystem(app)
        drawLifeBars(app)
        if app.characterOneHit == False and app.characterOneHitLong == False:
            drawImage(app.characterOneImage[app.characterOneFlip][app.imageCounter2],app.characterOneStartX - 35 ,app.characterOneStartY - 230 )
        else:
            if app.characterOneHit == True:
                drawImage(app.characterOneImagePunch[app.characterOneFlip][app.imageCounter1],app.characterOneStartX - 35 ,app.characterOneStartY - 230 )
                ryuPunch.play(loop=False)
            if app.characterOneHitLong == True:
                if app.characterOneFlip == 0:
                    drawImage(app.characterOneImageLongPunch[0][app.imageCounter1Long],app.characterOneStartX - 280 ,app.characterOneStartY - 200 )
                    hadouken.play(loop=False)
                else:
                    drawImage(app.characterOneImageLongPunch[1][app.imageCounter1Long],app.characterOneStartX   ,app.characterOneStartY - 200 )
                    hadouken.play(loop=False)
                
        if app.characterTwoHit == False and app.characterTwoHitLong == False:
            drawImage(app.characterTwoImage[app.characterTwoFlip][app.imageCounter2],app.characterTwoStartX - 35 ,app.characterTwoStartY - 215 )
        else:
            if app.characterTwoHit == True:
                drawImage(app.characterTwoImagePunch[app.characterTwoFlip][app.imageCounter2],app.characterTwoStartX - 255 ,app.characterTwoStartY - 260 )
                dhalsimYogaFire.play(loop=False)
            if app.characterTwoHitLong == True:
                if app.characterTwoFlip == 0:
                    drawImage(app.characterTwoImageLongPunch[0][app.imageCounter2Long],app.characterTwoStartX - 400 ,app.characterTwoStartY - 400 )
                    dhalsimYogaFlame.play(loop = False)
                else:
                    drawImage(app.characterTwoImageLongPunch[1][app.imageCounter2Long],app.characterTwoStartX - 90  ,app.characterTwoStartY - 400 )
                    dhalsimYogaFlame.play(loop = False)
        if len(app.characterOneLife) == 2:
            flag = True
            drawLabel('Player One Lives Left: 1', app.width/2, app.height/6, size = 25 , font='monospace',border = 'black' , borderWidth = 1, fill = 'red', visible = flag)   
            
            if app.steps% 2 == 0:
                flag = False 
            drawLabel('Player One Lives Left: 1', app.width/2, app.height/6, size = 25 , font='monospace',border = 'black' , borderWidth = 1, fill = 'red', visible = flag)   
            return
                    
        if len(app.characterTwoLife) == 2:
            flag = True
            drawLabel('Player Two Lives Left: 1', app.width/2, app.height/6, size = 25, font = 'monospace',border = 'black' , borderWidth = 1, fill= 'red', visible = flag)        
             
            if app.steps% 2 == 0:
                flag = False

            drawLabel('Player Two Lives Left: 1', app.width/2, app.height/6, size = 25 , font='monospace',border = 'black' , borderWidth = 1, fill = 'red', visible = flag)   
            return
        
    
    # drawLabel(f'Character {app.lastUser} , WON !!',400,400)
    
    # if app.gameOver and app.gameStatus == 'GameOver':
    #     drawGameOverMessage(app)
    winner = None
    if app.gameStatus == 'GameOver' :
        deathSound.play(loop = False , restart= False)
        # deathSound.pause()
        kO.play(loop = False, restart = False)
        # kO.pause()
        winner = app.winner
        drawGameOverMessage(app,winner)
    
    
    
    

    
    
    

def main():
    runApp(1000,600)

main()